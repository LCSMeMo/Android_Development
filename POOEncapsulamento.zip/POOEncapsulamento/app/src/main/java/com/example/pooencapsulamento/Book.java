package com.example.pooencapsulamento;

/*
Classe Livro - Encapsulamento

Atributos:
- Título - String
- Autor - String
- Paginas - int
- Editora - String
- Localização - String

Construtor: Constroi um objeto da Classe

Métodos:

+gets
+sets

+Localizar
+Adicionar
+Editar
+Apagar
*/

public class Book {
    private String title;
    private String author;
    private String publisher;
    private String location;
    private int pages;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }
}
