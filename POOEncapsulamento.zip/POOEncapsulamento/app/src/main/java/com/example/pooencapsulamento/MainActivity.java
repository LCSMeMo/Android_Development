package com.example.pooencapsulamento;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

        TextView textTituloLivro;
        TextView textAutor;
        TextView textEditora;
        TextView textLocalizacao;
        TextView textPaginas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        IniciarComponentesDoLayout();

        CreatObject();
    }

    private void IniciarComponentesDoLayout() {
       textAutor = findViewById(R.id.textAutor);
       textLocalizacao = findViewById(R.id.textLocalizacao);
       textPaginas = findViewById(R.id.textPaginas);
       textEditora = findViewById(R.id.textEditora);
       textTituloLivro = findViewById(R.id.textTituloLivro);

    }

    @SuppressLint("SetTextI18n")
    public void CreatObject(){
        Book book = new Book();

        book.setTitle("The Alchemist");
        book.setAuthor("Lucas");
        book.setPages(100);
        book.setLocation("H60");
        book.setPublisher("Novel");

        Log.i("POO","Book Title:" +book.getTitle());
        Log.i("POO","Book Author:" +book.getAuthor());
        Log.i("POO","Book Pages:" +book.getPages());
        Log.i("POO","Book Location:" +book.getLocation());
        Log.i("POO","Book Publisher:" +book.getPublisher());

        textAutor.setText("Autor do Livro: " +book.getAuthor());
        textLocalizacao.setText("Localização do Livro: " +book.getLocation());
        textPaginas.setText("Número de páginas do Livro: " +(book.getPages()));
        textEditora.setText("Editora do Livro: " +book.getPublisher());
        textTituloLivro.setText("Título do Livro: " +book.getTitle());

    }
}